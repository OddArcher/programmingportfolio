public interface Item{
    String name = "";
    public int use();
    public String displayStats();
}
