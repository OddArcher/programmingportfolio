
public class Boss extends Enemy{
    private String[] bossNames = {"Cell Lord Giant Slime","Cell Lord Skeleton Warrior","Cell Lord Executioner","Cell Lord Pit Demon"};
    private String[] bossNamesAlt = {"Cell Lord Cannibal Slime","Cell Lord Skeleton Sword Master","Cell Lord Dragon Slayer","Cell Lord Nightmare"};
    private String[][] bossAttacks = {{"Whip","Swipe","Drown"},{"Shield Bash","Slash","Impale"},{"Punch","Hammer Slam","Execute"},{"Inferno","Ram","Gore"}};
    private String[][] bossAttacksAlt = {{"Crush","Vomit","Consume"},{"Hilt Bunt","Dual Slash","Sword Spin"},{"Drop Kick","Spear Swipe","Slaying Stab"},{"Insanity","Reap","Soul Shred"}};
    private boolean alt = false;
    public Boss(int X, int Y){        
        super(X,Y);
        int temp = (int)(Math.random()*2);
        name = bossNames[choice];
        
        if(temp == 2){
            alt = true;
            name = bossNamesAlt[choice];
        }
        else{
            alt = false;
            name = bossNames[choice];
        }
        damage = 11;
    }
    public void attack(Oubliette game, Weapon myweapon){
        int mod = (int)(Math.random()*2);
        int temp = (int)(Math.random()*2);
        int chance = (int)((Math.random() * 150) + 1);
        if(temp == 2){
            System.out.println("The " + name + " uses " + bossAttacksAlt[choice][mod]);
        }
        else{
            System.out.println("The " + name + " uses " + bossAttacks[choice][mod]);
        }
        if(chance> ((myweapon.dodge + game.defbonus) * game.dodmod)){
            game.hit(game,((damage*(mod+1)) - (((myweapon.defense + game.defbonus)*game.defmod))));
        } 
        else{
            System.out.println("You dodge an attack.");
        }
    }
    public void display(){
        if(choice == 0 && alt == false){
            System.out.println("         `:://++++//::`");        
            System.out.println("       -+:/so/::/os/:+-");       
            System.out.println("      -oosdddh+ohdddsoo-");      
            System.out.println("      s/yhddhy/+yhddhy/s");      
            System.out.println("      y:+/++/::/+/++/+/y");      
            System.out.println("      +/oyooosyyso++yo/+");      
            System.out.println("      o:+yhdhhddhhdhy+/o");      
            System.out.println("     //:/+sssshyooys+::+/");     
            System.out.println("   `//::////++o+/+//:::://`");   
            System.out.println("  `+:///:::ooooooo+:::::::+`");  
            System.out.println("  .o-:://:++oooooo++::--:-o.");  
            System.out.println(" `:+-:/::/+oooooooo+/::::-+:`"); 
            System.out.println(".+::/:--:/::/+o+o+::/:-:/:::+.");
            System.out.println("h/:://-/::::://-:/:-/+-/::-//h");
            System.out.println(":ooo////::--:/--://:++:///ooo:");
            System.out.println("  ``::/+++ooooo+oooo+++/::``");   
        }
        if(choice == 0 && alt == true){
            System.out.println("               .-:::+o++/-.");        
            System.out.println("           `-+syy/``+hdddhys/.");       
            System.out.println("         -+yhhhysyysshdmmmmdhyo:");      
            System.out.println("      `:oshmdsydmmmmdyydmmmmmmdyo-");      
            System.out.println("     -ss---:/odmmhhdmmddmmmm/.-+sy+");        
            System.out.println("   `+sdd/-.` `+mmdddmmddmmmm-  `/myo`");       
            System.out.println("   +ydyhmmhs/-`hddmmmmddmmmmh- `+mmho");      
            System.out.println("  :ymd+oymmmmmmmmmmmmdhdmmmmmmdhdmydy/");    
            System.out.println("  sdh-`-`ommmoommmmmdhhmmmmmmmmmdy--ys`");        
            System.out.println(" `smo-   `dy. -mmh+..odmmmh:/hdy: `-+y-");       
            System.out.println(" `smmsy-  `    o:     .smh`  `    `-sy-");      
            System.out.println("  +mmmmy-    `          :`      :-`oms`");    
            System.out.println("  .hmmhhm: `omy.           /y. -mdhmh- ");        
            System.out.println("   `+mdmmmsymmmh-         /mmh+dmmmmmo");       
            System.out.println("   -mmmmmmmdddmmmo/+syhyyymmmmmmmmmmmm");      
            System.out.println("  oodmmmmmmmmmmmmddmmmmmmmmmmm+:hmmmh:");  
            System.out.println("  //`/oyhysmmms://+++++/:-smmd`  `.`");
            System.out.println("            ..             .-`");
        }
        if(choice == 1 && alt == false){
            System.out.println("                 -:---.`");
            System.out.println("                `o+.---.`");
            System.out.println("          ```````o-o+://`");
            System.out.println("         `++oososhos/o+y:");
            System.out.println("    .-  `:o/.:hs+os+++ohs-`");
            System.out.println("    ::--/s-  -hs++yhyo++myy+");
            System.out.println("   .--:/:/.- -hhysoo+:.+ddyy");
            System.out.println("  .::-:+/+o`/yysdhs+: .ody/s");
            System.out.println("-+ssyysyoo` :syhdddhy- `shs+");
            System.out.println(" -ydhddhy/ `:+hhyysyh/  `sy+.");
            System.out.println("`oyhyhyyy. :+y++yyooos:` `+++-");
            System.out.println(" .+hhhyhy--oy/ /o+:- ./+/-.:+/.`");
            System.out.println("   -+yyyo+yo.          +ds::`//-`");
            System.out.println("     -yhddd`           oddys  -/-`");
            System.out.println("     .dddmo            `ods/.  `:-``");
            System.out.println("     -shh/               /yyo`   .:.`");
            System.out.println("     +hhs                 yhs.    `--.");
            System.out.println("    :ssy:                `+yyso-.   ./.");
            System.out.println("  `+ys:`                    `-:+/.   `:.");
        }
        if(choice == 1 && alt == true){
            System.out.println("       `::..`");
            System.out.println("        `-://:.`");
            System.out.println("          `.:////-.`-:---.`");
            System.out.println("              .-/o+o//.--.:");
            System.out.println("                 `-ss:so+s/");
            System.out.println("                   :yshosho.`   .+.");
            System.out.println("              .--/.`oyhyho-+oo/sh+`");
            System.out.println("            -//+hoshdyhyyoo:`/hhdyyo`");
            System.out.println("         `-//:.o+hhhsoyyhsms/oo-oyyyo-`");
            System.out.println("     `:-:+:`  -ohyhhy+shh+s/so  `s+::o-");
            System.out.println("     .os+     -ooooss+yhys. -+. :s:");
            System.out.println("      oy-     .sysydyssys:   +:`o+`");
            System.out.println("      :o/    ``oyhdy/-+o:    :oo/:");
            System.out.println("      -o+  `:y+/ydshy+-      .y:+.");
            System.out.println("      -s+- ::yyoyddoho:.      .:.");
            System.out.println("      `sy.../o+.sy+:+++-.");
            System.out.println("  :yo+ohs+o:sys/-+::/so:-");
            System.out.println("   .syydy/+o/+++o++o` -:-");
            System.out.println("    .+oh/+oo+/--. -`  ./-");
            System.out.println("      +/::s`.-/+//:..`./:");
            System.out.println("       ::/y+`   `-:/://:-:`");
            System.out.println("        +oo/+       ..://::--.");
            System.out.println("         `///+         //+::::/.");
            System.out.println("           -/++        `/s.");
            System.out.println("            ./+/        /+.");
            System.out.println("             `/:/`      +/:");
            System.out.println("              -oso/-    soo");
            System.out.println("            ./yyyo:    -y+hs/`");
            System.out.println("         `oyy+/-`        -/shy`");
        }
        if(choice == 2 && alt == false){
            System.out.println("        `//+o++-.        .-.");
            System.out.println("        ://-++++o+.      o/o  `");
            System.out.println("       `/+soososos+  -:-+ssso:/-`");
            System.out.println("      :+o+/-+osyhy.-+sooos+soooyo:");
            System.out.println("    `:/+:/://soohyys+o+:://::/+soo++`");
            System.out.println("   .:/-:+-:o+soo+:syo++++++o+:/++oos` ");
            System.out.println(" `-//::/-:::+y+s. ``:///:--:/oss+o++`");
            System.out.println(".ossyso///+/os++`  `++/++:-/:/o+o:.:/+:");
            System.out.println("-hhhhyyhhhyys/++`  .sssyooossoyyy:");
            System.out.println(" `/yhyhhhhhyyyys`  :-/oyyhyyhhho+:");
            System.out.println("    .:+syyhddhs-  ./:/+oyo++syoo++.");
            System.out.println("          `..`   `+ssyy/:/o++osssso");
            System.out.println("                  ./ooo`.////:oos:.");
            System.out.println("                    //: `..`.`+//");
            System.out.println("                   .+oo      `+o+-");
            System.out.println("                  -/::.       `.-/:");
        }
        if(choice == 2 && alt == true){
            System.out.println("  `                  `-:-");
            System.out.println("  --               .omNms..");
            System.out.println("   ./`             dNNdss/-");
            System.out.println("    `/-           oNNdyhy+-");
            System.out.println("      ::`       .hNNNd/yhhhy+/.");
            System.out.println("       -++.     ommdddmhhhyhhys:-:");
            System.out.println("        :+/       `sdsoosyyhmshys/.");
            System.out.println("          -/.//`   +mooohhyd/ -:/sss+/o.");
            System.out.println("          .+o:   `+dmmsohhyo`      `");
            System.out.println("         .-  :/./yy+sddddhyy:");
            System.out.println("              .yd- .sdNmNmhhy/`");
            System.out.println("                +o.yymmmmmhyys/");
            System.out.println("                 :ysmNNNmNhyyyo/");
            System.out.println("                 +hdNNNMMMNmdyso+");
            System.out.println("                +sNmNNNmyss+yyys//-");
            System.out.println("              `/yyNmNMm.    /ddso+`");
            System.out.println("              :ohmmmNNy/.   :dyy/");
            System.out.println("              `+hmms+o. :`  +:sd+`");
            System.out.println("               .yy:           `ys.");
            System.out.println("             `+dh.             .y+`");
            System.out.println("            -ossy-              /+-");
        }
        if(choice == 3 && alt == false){                                                  
            System.out.println("                 ``     ``.````..```..   ");        
            System.out.println("              `.``.-::/:-yhs+..++/:/yh-` ");        
            System.out.println("        .    `:hs-.+o/+`+o+/-odddhooso-:-`");       
            System.out.println("       :.   .::hmy.-:--./--.+omNdyyhyy/y/-.");      
            System.out.println("      `o   -/oohso.+::/:/soshshNs` `-o:+h+:-");     
            System.out.println("      `s--::oso+. .+s+:yossNdsmdh/    ./ohs/-");    
            System.out.println("      `:s+o://:`  .oo+:/syshs/sdy/-   `+yddho");    
            System.out.println("       ./::::.   `---+:.:+/:+osyo::`   `:yyy-");    
            System.out.println("        ````     .-`/s-`-/+ohmNmh+ss.`");           
            System.out.println("              ``./h/hNdyhhyyhdyoo//.`.-:.");        
            System.out.println("          -..:::oo/:yhmhh:omhss/.`-.```yds-  .");   
            System.out.println("        ``.-:::s+/.:o/ds::mho/+-``-..-/o++oysd` "); 
            System.out.println("      `  ``-.`.``..`.::y`--.`     ``   `y:..+dds ");
            System.out.println("     .``..s- `..   .--//  ```:-``````   :h`..sNN/");
            System.out.println("     /.`-so  `   `. .+h```.``-::.` `+y`  : .:`dNy");
            System.out.println("    `:-+mNy`      ./+hs```./+:---``/mNo``-./h:yMh");
        } 
        if(choice == 3 && alt == true){
            System.out.println("            .+                                ``");
            System.out.println("       /.    s:   -                      .`  `+`");
            System.out.println("       `/y/ohdmhood/...               -`.sysydmhs+//");
            System.out.println(" -/:.-ohmmmmmdhdhhhyyy/:/.://+++:::/+yyyhhdhddmmmmdy/```");
            System.out.println("    .mmNNMNMMMMMNNMmhhyhmdhs+/++oydmhhhhdmNNMMMMMNNMNmh:");
            System.out.println("   :ymNMMMmhyhyyyNMMMNmNmdho:::/+yhhmNNNMMmshNdddhNMNNmm-");
            System.out.println("   +NNNMN/       `dMMM==hhyhhssyhy==NNMMs`       +NMNNNh");
            System.out.println("   /NMMMs        -mMMNN==NNmyo+ym==dsNNMNd-       `-NMMNd ");
            System.out.println("  `hmMMNN-   `:oyNMMMMNh==hsy+/==hyssNMMMMNms:`    sMMMN-");
            System.out.println("    -dMNNo`:smNMNNNNNmMNmmdhhmdmydmdNMdhhNNNNNmy/.:dNMNo");
            System.out.println("     .sNNmddNNmdyo:.:oNMMMmdmMMmdmMMMNh+:-+shmNNmhdmNd-");
            System.out.println("      `oNNmmddd+/.+h+dNMMMMMMMNMMMNMMNmsys::+dddmmNNh-");
            System.out.println("     :hmdy/.-:+ydmNdshNmdNmdNhydmdmMNmdyhmmddo/-.-+dmds`");
            System.out.println("    +hh+`     `smNmhh+` /mmdmhhhdhNy``/dddmNh-     `:sdy.");
            System.out.println("   +y/`       :ydhdmd.  -/shyssshdm-   ymddmd+        -oy.");
            System.out.println("  -+`         `omNNh-     .+`.`.-:.    .hmmms.          :+");
            System.out.println("  `             ./:                     `-/:             `");

        }
    }
}
