public class Enemy extends NPC{
    private String[] names = {"Slime","Skeleton","Knight","Demon"};
    private String[][] attacks = {{"Slam","Splash","Engulf"},{"Bash","Claw","Tear"},{"Kick","Slash","Stab"},{"Enflame","Impale","Mutilate"}};
     String name;
     
     int health;
     int damage;
     int choice;
     int x;
     int y;
     int score;
     String[] iconlist = {"E","S","K","O"};
    String icon = "E";
    public Enemy(int X, int Y){
        choice = (int)(Math.random()*4);
        name = names[choice];
        health = 50 * (choice+1);
        damage = 5 * (choice+1);
        x = X;
        y = Y;
        score = damage*(choice+1);
        icon = iconlist[choice];
    }
    public void attack(Oubliette game, Weapon myweapon){
        int mod = (int)(Math.random()*2);
        int chance = (int)((Math.random() * 100) + 1);
        System.out.println("The " + name + " uses " + attacks[choice][mod]);
        if(chance> ((myweapon.dodge + game.defbonus) * game.dodmod)){
            game.hit(game,((damage*(mod+1)) - (((myweapon.defense + game.defbonus)*game.defmod))));
        } 
        else{
            System.out.println("You dodge an attack.");
        }
    }
    public void display(){
        if(choice == 0){       
            System.out.println("                -//`   `");
            System.out.println("                 shds-`oh+");
            System.out.println("                .yyyyyyhhy`");
            System.out.println("               `ohyyshyyyy:");
            System.out.println("              `soyhhhmddds+");
            System.out.println("              :yhdddmddddhy:");
            System.out.println("             .shhddhmdddhhhs`");
            System.out.println("            -syyyyhsdhhhyyyh.");
            System.out.println("           :ossyhhssyyyyyyhy/");
            System.out.println("          .osyyyhyyyyyyyyyhhy+`");
            System.out.println("        `-osyyyyyhyyhsyyhhhyyso:.");
            System.out.println("`.....-/ssyyhyyyyhyyhsyyhhyhhysooo/-.");
            System.out.println("`-//-..+soosysyyyyyysyyyyyyyo+/-:/-");
            System.out.println("     ./+///+/-..-sysoysoooososo+//-");
            System.out.println("                 `--:/+++++/-.");
        }
        if(choice == 1){       
            System.out.println("           ````.`");             
            System.out.println("           +/:+++");             
            System.out.println("           ssssy/");             
            System.out.println("           -yssy`");             
            System.out.println("          ./sdhds+:.");          
            System.out.println("       `.:+ssooosos+/-`");       
            System.out.println("       :+/osoo+oooso/:-");       
            System.out.println("      .:/ +yss+ssyyo :-.");      
            System.out.println("      -/` :yssssssy+  :-`");     
            System.out.println("     `:-   /o/oysoo:  `:- ");    
            System.out.println("     :/`   `-.:oo/-.   -/.");    
            System.out.println("    :+/   `://+yy++-    ++/");   
            System.out.println("   `/s.   `./:+oo/:..   `+:- "); 
            System.out.println("   ./.   .--..-.-``-.`   .-- "); 
            System.out.println("  `-.    .-`       ..`    -.");  
            System.out.println("`.--    .-`        ...    .::-");
            System.out.println("ohh.   `--         ---    oddh");
            System.out.println(":ddo  `-:-         -::.  `osd:");
        }
        if(choice == 2){
            System.out.println("                              .:+oo+-");  
            System.out.println("             . -`       `-+ohdmmmmdo`");                       
            System.out.println("            .d+yyss+syhddmmmmmmhs/.");  
            System.out.println("              oddmdddmmmmmmyo:`");  
            System.out.println("           `..sdmmddmmmms:");                       
            System.out.println("       ++/smmNmsmNNmddmdoo:.");  
            System.out.println("     .omNNdNNmdsmNNmmmmdmmmmy`");  
            System.out.println("     `  `.`:sdmmNmNmdsohdsdyo`");                       
            System.out.println("             .dNdyohy-oo- o+:oy.");  
            System.out.println("              ``  .``:y..-.mddh");  
            System.out.println("                 /mdhdmmmm/dmd/");                       
            System.out.println("                 -ymmmmmmNosmm/");  
            System.out.println("                `  o:odmh:osdd-");  
            System.out.println("               omhys `:sd//hh/");                       
            System.out.println("               odmNms smdmd");  
            System.out.println("                -mmmd  hNmm");  
            System.out.println("                 hmmd  /Nmm-");                       
            System.out.println("                 ymmy  /mmm-");  
            System.out.println("               `ydmmh  ommm`");  
            System.out.println("               :o+/-   `/:`");                       
        }    
        if(choice == 3){
            System.out.println("                          :++/--:..`");
            System.out.println("                        +dNNmNmmmmmmy`");
            System.out.println("                      `hNNNNmmNmmmNNNm/");
            System.out.println("           .`        `hNNNNNNNmNmmNNNNm+");
            System.out.println("          -mms`+`    :NNNNNNNmNNNmmyhmmd`");
            System.out.println("        ./dNNNhmhoo..hmmh.odmNNNNNs  /ms");
            System.out.println(" `.:shmmmmNmNNmNmmmmNmysshmdmmmmmNh- -dh.``");
            System.out.println(".mNNNNNNmmmmNdsdh-./+.  /NNNNNNNNNNNhymmdmy/`");
            System.out.println(" :dMMNNNNNNNNomNNmhy:   dNNNmsNNmNNNN/./:.::`");
            System.out.println("   .-hmNNNs`.yNNd/+:    yNNm` dd`sNNm-");
            System.out.println("       .sy- `..--       -NNd` +s /NNd");
            System.out.println("                         hN:  .o `hNo");
            System.out.println("                        :mm+   . .hmd:`");
            System.out.println("                     `:+osoo      .syss+:`");

        }
    }
}

