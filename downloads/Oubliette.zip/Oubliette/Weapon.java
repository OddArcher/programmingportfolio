public class Weapon implements Item{
    public String[] names = {"Gauntlets","Sword & Shield","Bow","Scythe","Kitana", "Great Sword"};
    public String[][] attackMoves = {{"Hook","Uppercut","Combo","Flurry"},{"Slash","Lunge","Plunging Slash","Decapitate"},{"Quick Fire","Full Power","Burst","Critical Shot"},{"Swipe","Reaching Swipe","Impale", "Reap"},{"Low Swipe","Mid Slash","High Strike","Thousand Cuts"},{"Heavy Slash","Mega Lunge","Sword Drop","Decapitate"}};
    public String[] defenseMoves = {"Defensive Jab","Shield Bash","Reposition","Spike","Hilt Blow","Shaking Block"};
    String name;
    String[] aMoves;
    String dMove;
    int type;
    int attack;
    int defense;
    int dodge;
    public Weapon(int input, int level){
        type = input;
        name = names[input];
        aMoves = attackMoves[input];
        dMove = defenseMoves[input];
        if(input == 0){
            attack = 5;
            defense = 6;
            dodge = 10;
        }
        if(input == 1){
            attack = 7;
            defense = 10;
            dodge = 5;
        }
        if(input == 2){
            attack = 8;
            defense = 3;
            dodge = 10;
        }
        if(input == 3){
            attack = 10;
            defense = 3;
            dodge = 6;
        }
        if(input == 4){
           attack = 10;
           defense = 2;
           dodge = 8; 
        }
        if(input == 5){
           attack = 20;
           defense = 5;
           dodge = 5;
        }
        attack += (int)(Math.random() * level);
        attack += (int)(Math.random() * level);
        attack += (int)(Math.random() * level);
    }
    public int use(){
        return attack;
    }
    public String displayStats(){
        return " stats: ATK-" + attack + " DFN-" + defense + " DEX-" + dodge;
    }
    public void display(){
        if(type == 0){ 
            System.out.println("");
            System.out.println("           .-:.`                                                 `.-- ");
            System.out.println("         `:/+/++/-`                                          `-:+++o+: ");
            System.out.println("        -//:+/+o++/:.                                     `-/+++o+++///`");
            System.out.println("       :/+///oooo+/+//.                                 ./++/+ooooo////:");
            System.out.println("      -///++oooooo+o++/:`                             `-::+o+/oooss+//:/-");
            System.out.println("     `+///ooooos++oo+//-..                           --.-:+oo++ooss++////");
            System.out.println("     `o+/+ooosso++oyo//:---                         //::-:+so+++oso+++//+");
            System.out.println("     `s++++ossso++ooo//://o-                       :s+:-++ooo+++os+++//++");
            System.out.println("      :o++++oso+++oo+o+:-oo+                       /oo+/oooo+++++o++///o-");
            System.out.println("      `oo++++o++++oooo+/+s+.                       :syo:osso++/+++++++o/");
            System.out.println("       +so+++++++oooooo+hhs:                       +h+`:ossoo+/++++++o+`");
            System.out.println("       .syo+++osooosso++shd+  -:                   /+/./osso+ooo++++so:");
            System.out.println("       `yysss+ooooooso/osos-/oo`                   -ss:./++++o//+sosso");
            System.out.println("        :hyossosssoss+:+soso/.                      /o--+ss/+o+/+/ohy/");
            System.out.println("        `odyo++ooo++/-/oo.                         /o:-/oo.:-/+ssss/");
            System.out.println("         :ho+/+++o/+o--+o.                         `++::/o/`+--::+so");
            System.out.println("         -oo/-/::o/+o//+s/                       `.oso:/o/``+`:.:+:");
            System.out.println("   ``.---//+.--.+/`/+/osss/. ``                   +oyso:/++` /-.-`//.");
            System.out.println("   ./osyo/+-:/--+- /+/oshhss/:+/o`:            ++/`/hs:///o-`-+.:.-//.");
            System.out.println("      .+/+::+//oo:.oo+ooshdy---so-oss.       /s/+:+NmN+-.-o+:://-/-.//`");
            System.out.println("    .///++:/++o///-o/-ooodNmy+/+/sso:        -o+odNNNNm+-/o+o+++o+o/++/-`");
            System.out.println("   .+oos+++oo+o+ssss+/osddmNNyosss+-         `os-NMMNNd/-+++hhoooso+++o++");
            System.out.println("   /osdyo++h+oo-NNy+o:dNNNNMmso:y/`           //yNNMMm/.++/sd+o++dd/+yyos`");
            System.out.println("  .+ohmo++/d+o+.hNh++:ymodNMmoo:y-           -o:dNMmd+-/++yms/++smh//sd+o`");
            System.out.println(" :+/+md+/++d++//yNmo+o+s` :mdo/+s`           -s-mNh-s/-/:yNs:+/+dNo+:+d++-");
            System.out.println(" +--sNo:::hh/:/:hmNsss/+/ :Nms++/            `yhNy.o/-/:hNm::+:+mNoo:-y--/.");
            System.out.println(" :+-omy:-syd/`+:sN:yoo/s`  -ydyo-             :+-`oo./:sdhh:s:+hmdo//oy//-");
            System.out.println(" -/:sdd:.h+m+ s-sm/yoo:s`                        /+:++ymoh:y+:myNh+:/ys/:");
            System.out.println(" :/-shd/.y+d/`s-ydhy/s:s.                       .s//+yNos+/s-mdomy+//s//:");
            System.out.println(" `/./sy/-+sm+-o:sNNh++:+`                       `//+smmo+/+:+m-ydo/`::-/`");
            System.out.println("  ./+sh/./sm:-//+NNy///:                          .--:s/-/:/h::ds+:.+/:`");
            System.out.println("   `-/ss++hd.://oymdoo-`                             /h/+//oo`+mdso-:.");
            System.out.println("       -+sydo++++``.-`                                -///:`   -+o.");
            System.out.println("           -/+:.");
            System.out.println("");
        }
        else if(type == 1){
            System.out.println("                                                      `+-");
            System.out.println("                                                    .+hso`");
            System.out.println("                                                    syys.");
            System.out.println("                                                  `oss:.");
            System.out.println("                                                 -sys.");
            System.out.println("                                                /syo`");
            System.out.println("                                              `+sy:");
            System.out.println("                                             .oss.");
            System.out.println("                                      :`   :sso`");
            System.out.println("                                   .:+os++osys:");
            System.out.println("                                  .+yyssss+osy:");
            System.out.println("                                    `:-os+/osso+/");
            System.out.println("                                      -+/+sssssy`");
            System.out.println("                          ``````     `:://. .+sh`");
            System.out.println("                     ```.//-.-:..-.``-:/.");
            System.out.println("              ````.-/+syhhsoohho+oyys+:.`");
            System.out.println("              .:-`.-yoohh-/shhhyo+`oso+o` ..");
            System.out.println("              --/:/s:shho.-yhooyy: /ys+./-``");
            System.out.println("              ::ddy.sy+:.+hyosssyy+ .:+/`+oo");
            System.out.println("              :/dd/./-/oyhy++sy++yso/:`` .oo");
            System.out.println("              ::ddyssyddhhhhhhyyyyyyys+///oo");
            System.out.println("              -:hddhyyhhhsyhhhsyyyoooo+/:+oo");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
        }
    }
}
