public abstract class NPC{
    int x;
    int y;
    int score;
    String icon;
    public void attack(){};
    public void display(){};
}
