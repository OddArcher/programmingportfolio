import java.util.Scanner;
import java.util.ArrayList;
//LOOT
//MORE WEAPONS
//MAKE BETTER
public class Oubliette{
    private boolean playing = true;
    private int width = 19;
    private int height = 19;
    private String wall = "#";
    private String floor = ".";
    private String door = "D";
    private String player = "@";
    private String enemy = "&";
    private String[][] grid = new String[width][height];
    private String row1 = "...................";
    private String row2 = "...................";
    private String row3 = "...................";
    private String row4 = "...................";
    private String row5 = "...................";
    private String row6 = "...................";
    private String row7 = "...................";
    
    private int hp = 100;
    private int tp = 0;
    private String stance = "Defensive";
    
    private int score = 100;
    private int x = 10;
    private int y = 3;
    
    private int hitSelf = 0;
    
    private int winscore = 500;
    
    ArrayList<Enemy> enemylist = new ArrayList<Enemy>();
    int[] occupied = {-1,-1};
    
    boolean battle = false;
    
    private int level;
    int defbonus;
    int dodbonus;
    int defmod;
    int dodmod;
    int bandages;
    public Oubliette(){
        playing = true;
        //Room
        width = 19;
        height = 7;
        wall = "#";
        floor = ".";
        door = "D";
        player = "@";
        enemy = "&";
        grid = new String[height][width];
        row1 = "...................";
        row2 = "...................";
        row3 = "...................";
        row4 = ".........@.........";
        row5 = "...................";
        row6 = "...................";
        row7 = "...................";
        //Player
        hp = 100;
        score = 0;
        x = 9;
        y = 3;
        
        hitSelf = 0;
        
        winscore = 500;
        ArrayList<Enemy>enemylist = new ArrayList<Enemy>();
        int[] occupied = {3,9};
        battle = false;
        level = 0;
        defmod = 1;
        dodmod = 1;
        bandages = 5;
    }
    
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);
        Oubliette room = new Oubliette();
        Weapon myweapon = new Weapon(1,0);
        while(room.playing == true){
        System.out.print('\u000C');
        if(room.battle == true){
                System.out.println("You are fighting a " + room.enemylist.get(0).name + ".");
                System.out.println("--------------------------------------------------");
                room.enemylist.get(0).display();
                System.out.println("--------------------------------------------------");
                System.out.println(room.enemylist.get(0).name + " Health - "+ room.enemylist.get(0).health);
                System.out.println("HP - "+ room.hp + "  TP - " + room.tp);
                if(room.stance.equals("Offensive")){
                    System.out.println("Moves - ["+myweapon.aMoves[0]+"-5] ["+myweapon.aMoves[1]+"-10] ["+myweapon.aMoves[2]+"-15] ["+myweapon.aMoves[3]+"-20]");
                    System.out.println("Stance - " + room.stance + " [Switch]");
                    String input = keyboard.nextLine();
                    System.out.println("--------------------------------------------------");
                    if(input.equals("end") || input.equals("END") || input.equals("stop") || input.equals("STOP") || input.equals("die") || input.equals("DIE") || input.equals("kill yourself") || input.equals("killyourself") || input.equals("kill self") || input.equals("killself")){
                        endGame(room);
                        System.out.println("Game Over. Thanks for playing.");
                    }
                    else if(input.equals("die") || input.equals("DIE") || input.equals("kill yourself") || input.equals("killyourself") || input.equals("kill self") || input.equals("killself")){
                        die(room);
                        System.out.println("Game Over. Thanks for playing.");
                    }
                    else if(input.equals(myweapon.aMoves[0]) || input.equals(myweapon.aMoves[0].toLowerCase()) && room.tp>=5){

                        attack(room,0,myweapon);
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        clearBonus(room);
                    }
                    else if(input.equals(myweapon.aMoves[1]) || input.equals(myweapon.aMoves[1].toLowerCase()) && room.tp>=10){

                        attack(room,1,myweapon);
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        clearBonus(room);
                    }
                    else if(input.equals(myweapon.aMoves[2]) || input.equals(myweapon.aMoves[2].toLowerCase()) && room.tp>=15){

                        attack(room,2,myweapon);
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        clearBonus(room);
                    }
                    else if(input.equals(myweapon.aMoves[3]) || input.equals(myweapon.aMoves[3].toLowerCase()) && room.tp>=20){
                        
                        attack(room,3,myweapon);
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        clearBonus(room);
                    }
                    else if(input.toLowerCase().equals("switch")){
                        room.stance = "Defensive";
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        clearBonus(room);
                    }
                    else{
                        System.out.println("You can't do that right now.");
                    }
                    System.out.println("PRESS ENTER");
                }
                if(room.stance.equals("Defensive")){
                    System.out.println("Moves - [Attack] ["+myweapon.aMoves[0]+"-5] [Block] [Dodge] [Item]");
                    System.out.println("Stance - " + room.stance + " [Switch]");
                    String input = keyboard.nextLine();
                    System.out.println("--------------------------------------------------");
                    if(input.equals("end") || input.equals("END") || input.equals("stop") || input.equals("STOP") || input.equals("die") || input.equals("DIE") || input.equals("kill yourself") || input.equals("killyourself") || input.equals("kill self") || input.equals("killself")){
                        endGame(room);
                        System.out.println("Game Over. Thanks for playing.");
                    }
                    else if(input.equals("die") || input.equals("DIE") || input.equals("kill yourself") || input.equals("killyourself") || input.equals("kill self") || input.equals("killself")){
                        die(room);
                        System.out.println("Game Over. Thanks for playing.");
                    }
                    else if(input.toLowerCase().equals("attack")){
                        System.out.println("You rush the enemy for 10hp.");
                        room.enemylist.get(0).health-=10;
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        room.tp+=5;
                        System.out.println("+5tp");
                        clearBonus(room);
                    }
                    else if(input.toLowerCase().equals(myweapon.aMoves[0].toLowerCase()) && room.tp>=5){
                        System.out.println("You use " + myweapon.aMoves[0] + " tactically attacking for 10hp.");
                        room.enemylist.get(0).health-=10;
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        room.tp-=5;
                        System.out.println("-5tp");
                        if(myweapon.type == 0 || myweapon.type == 2 || myweapon.type == 3 || myweapon.type == 4){
                            room.dodbonus += 10;
                            System.out.println("Dodge Bonus For Next Turn");
                        }
                        if(myweapon.type == 1 || myweapon.type == 4 || myweapon.type == 5){
                            room.defbonus += 10;
                            System.out.println("Block Bonus For Next Turn");
                        }
                    }
                    else if(input.toLowerCase().equals("block")){
                        System.out.println("You put your focus on blocking the next strike.");
                        room.defmod = 2;
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        room.tp+=6;
                        System.out.println("+6tp");
                        clearBonus(room);
                    }
                    else if(input.toLowerCase().equals("dodge")){
                        System.out.println("You put your focus on dodging the next strike.");
                        room.dodmod = 2;
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        room.tp+=6;
                        System.out.println("+6tp");
                        clearBonus(room);
                    }
                    else if(input.toLowerCase().equals("item") && room.hp <= 60 && room.bandages >0){
                        System.out.println("Use a bandage? [Yes/No-"+room.bandages+"]");
                        input =  keyboard.nextLine();
                        if(input.toLowerCase().equals("yes") || input.toLowerCase().equals("y")){
                            room.hp += 40;
                            if(room.hp > 100){
                                room.hp = 100;
                            }
                            room.bandages--;
                            System.out.println("You patch up.");
                            System.out.println("+40hp");
                        }
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        clearBonus(room);
                    }
                    else if(input.toLowerCase().equals("switch")){
                        room.stance = "Offensive";
                        if(room.enemylist.get(0).health>0){
                            room.enemylist.get(0).attack(room,myweapon);
                        }
                        clearBonus(room);
                    }
                    else{
                        System.out.println("You can't do that right now.");
                        
                    }
                    
                    
                }
                if(room.enemylist.get(0).health<=0){
                    System.out.println("You have killed your enemy. You have found " + room.enemylist.get(0).score + " gold on the body.");
                    room.enemylist.remove(0);
                    Weapon tempw = new Weapon((int)(Math.random() * 5),room.level);
                    System.out.println("You find a " + tempw.name + ".");
                    System.out.println("It's " + tempw.displayStats());
                    System.out.println("Your "+myweapon.name+"'s " + myweapon.displayStats());
                    System.out.println("Swap Weapons? [Yes/No]");
                    String input =  keyboard.nextLine();
                    if(input.toLowerCase().equals("yes") || input.toLowerCase().equals("y")){
                        System.out.println("You switch weapons.");
                        myweapon.type = tempw.type;
                        myweapon.name = tempw.name;
                        myweapon.aMoves = tempw.aMoves;
                        myweapon.dMove = tempw.dMove;
                        myweapon.attack = tempw.attack;
                        myweapon.defense = tempw.defense;
                        myweapon.dodge = tempw.dodge;
                        System.out.println("PRESS ENTER");
                    }
                    room.level++;
                    room.battle = false;
                    room.stance = "Defensive";
                }
                else if(room.hp<=0){
                    endGame(room);
                    die(room);
                    System.out.println("You Died. Game Over. Thanks for playing.");
                }
                else{
                    //System.out.println("PRESS ENTER");
                }
                System.out.println("--------------------------------------------------");
                if(room.playing == true){
                   String input = keyboard.nextLine();
                }
        }
        else{
            //clearScreen();
            if(room.enemylist.size() > 0){
                room.door = "L";
            }
            else{
                room.door = "D";
            }
            System.out.println("##########"+room.door+"##########");
            System.out.println("#"+ room.row1 +"#");
            System.out.println("#"+ room.row2 +"#");
            System.out.println("#"+ room.row3 +"#");
            System.out.println(room.door + room.row4 + room.door);
            System.out.println("#"+ room.row5 +"#");
            System.out.println("#"+ room.row6 +"#");
            System.out.println("#"+ room.row7 +"#");
            System.out.println("##########"+room.door+"##########");
            System.out.println("   HP-"+room.hp+" Gold-"+room.score+"    ");
            System.out.println("---------------------");
            String input = keyboard.nextLine();
            if(input.equals("w") || input.equals("W") || input.equals("up") || input.equals("UP") || input.equals("north") || input.equals("NORTH")){
                moveUp(room);
                setRoom(room);
                changeRoom(room);
            }
            else if(input.equals("a") || input.equals("A") || input.equals("left") || input.equals("LEFT") || input.equals("west") || input.equals("WEST")){
                moveLeft(room);
                setRoom(room);
                changeRoom(room);
            }
            else if(input.equals("s") || input.equals("S") || input.equals("down") || input.equals("DOWN") || input.equals("south") || input.equals("SOUTH")){
                moveDown(room);
                setRoom(room);
                changeRoom(room);
            }
            else if(input.equals("d") || input.equals("D") || input.equals("right") || input.equals("RIGHT") || input.equals("east") || input.equals("EAST")){
                moveRight(room);
                setRoom(room);
                changeRoom(room);
            }
            else if(input.equals("wait") || input.equals("WAIT") || input.equals("q") || input.equals("Q")){
                setRoom(room);
                changeRoom(room);
                System.out.println("You wait.");
            }
            else if(input.equals("credits") || input.equals("CREDITS")){
                System.out.println("Rickles waz here.");
            }
            else if(input.equals("help") || input.equals("HELP")){
                System.out.println("Just walk around dude. Ask Ricky for the commands.");
            }
            else if(input.equals("hit") || input.equals("HIT")){
                System.out.println("You are hit yourself.");
                if(room.hitSelf >= 3){
                    System.out.println("Why are you hitting yourself?");
                }
                room.hp-=10;
                System.out.println("-10hp");
                room.hitSelf++;
                
                if(room.hp<= 0){
                    endGame(room);
                    die(room);
                    System.out.println("You Died. Game Over. Thanks for playing.");
                }
                
            }
            else if(input.equals("score") || input.equals("SCORE")){
                System.out.println("You found an invisible coin somehow.");
                room.score+=1;
            }
            else if(input.equals("yell") || input.equals("yell into the void")){
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH");
            }
            else if(input.equals("win") || input.equals("Win")){
                endGame(room);
                System.out.println("You Win! Thanks for playing.");
            }
            else if(input.equals("end") || input.equals("END") || input.equals("stop") || input.equals("STOP") || input.equals("die") || input.equals("DIE") || input.equals("kill yourself") || input.equals("killyourself") || input.equals("kill self") || input.equals("killself")){
                endGame(room);
                if(input.equals("die") || input.equals("DIE") || input.equals("kill yourself") || input.equals("killyourself") || input.equals("kill self") || input.equals("killself")){
                    die(room);
                }
                System.out.println("Game Over. Thanks for playing.");
 
            }
            else if(input.equals("look") || input.equals("look around") || input.equals("Look Around") || input.equals("investigate")|| input.equals("about")){
                System.out.println("You are in a dungeon.\nEach cell is connected to another prisoner.\n Kill enough of the others in an\nentertaining way and they just might let you out.");
                System.out.println("PRESS ENTER");
                input =  keyboard.nextLine();
            }
            else if(input.equals("gay") || input.equals("GAY")){
                System.out.println("You are now gay.");
                System.out.println("PRESS ENTER");
                input =  keyboard.nextLine();
            }
            else if(input.equals("trash") || input.equals("TRASH")){
                System.out.println("You are trash.");
                System.out.println("PRESS ENTER");
                input =  keyboard.nextLine();
            }
            else if(input.equals("liamsux") || input.equals("LIAMSUX") || input.equals("liam sux") || input.equals("LIAM SUX") || input.equals("liamsucks") || input.equals("LIAMSUCKS") || input.equals("liam sucks") || input.equals("LIAM SUCKS")){
                System.out.println(":::::::::::://////::::--------");
                System.out.println("::::::::/+ooosyyyyhys+/:------");
                System.out.println("::::-:+oososyysssyyyyyyo+/----");
                System.out.println("::---/so//+oosssoooo+sssoso/--");
                System.out.println("::::/+++++++syso+o+///+++sss+-");
                System.out.println(":::+oooo++oyyo//oo/:::/+o+oso:");
                System.out.println("::/oooo/:::::---::::---://+++/");
                System.out.println("::/++/:---:::::-----------:/+:");
                System.out.println(":://:---:///+oo+/::::////:://:");
                System.out.println("::/:---::++sssoo+::/osso+/:///");
                System.out.println(":++/------:////::-.:+oys+/:::+");
                System.out.println("::::--:::---------.---:::---/o");
                System.out.println("::---://////++//+/::::-----::+");
                System.out.println("///:://+++oo+//osoo++o+///:::/");
                System.out.println("oyhy:////ossysooooo++sso+/:--:");
                System.out.println("ssdNo//////+osyyysyhyoo++/----");
                System.out.println("yhmNo+++//:://+++++///+//-::::");
                System.out.println("yhhy++oo+/::::/+++/:::+sh+://:");
                System.out.println("hhhhs++syso+/::::--:+osNMms+/:");
                System.out.println("hhddds/+syhyysoo++/hdhyhMddo:/");
                System.out.println("dhhhddho+syhhhyso++Nmhhdmmd/-:");
                System.out.println("NNmmmmmmyssyysso++sMNmmmmdys+/");
                System.out.println("dmNNNNNNNNdyo++//odNNmdhydmNs+");
                System.out.println("osyhdmNNNNNNmdyydNNNdhyhhdysoo");
                System.out.println("Lol, true.");
                System.out.println("PRESS ENTER");
                input =  keyboard.nextLine();
            }
            else if(input.equals("inspect") || input.equals("INSPECT")){
                System.out.println("Your "+ myweapon.name +"'s" + myweapon.displayStats());
                System.out.println("PRESS ENTER");
                input =  keyboard.nextLine();
            }
            else if(input.equals("hax") || input.equals("cheat") || input.equals("godmode")){
                System.out.println("You feel powerful");
                room.hp = 999;
                room.tp = 999;
                System.out.println("PRESS ENTER");
                input =  keyboard.nextLine();
            }
            else if(input.toLowerCase().equals("item") && room.bandages >0){
                        System.out.println("Use a bandage? [Yes/No-"+room.bandages+"]");
                        input =  keyboard.nextLine();
                        if(input.toLowerCase().equals("yes") || input.toLowerCase().equals("y")){
                            room.hp += 40;
                            if(room.hp > 100){
                                room.hp = 100;
                            }
                            room.bandages--;
                            System.out.println("You patch up.");
                            System.out.println("+40hp");
                            
                        }
                        clearBonus(room);
            }
            else{
                System.out.println("I don't understand.");
            }
            
            System.out.println("---------------------");
            
        }
        
        }
    }
    
    public static void endGame(Oubliette game){
        game.playing = false;
    }
    
    public static void moveLeft(Oubliette game){
        if(game.y == 3 && game.x == 0 && game.enemylist.size() == 0){
            game.x = 18;
            game.y = 3;
            System.out.println("You go into the left door.");
            createEnemy(game);
        }
        else if(game.x>0){
            game.x -= 1;
            System.out.println("You go left.");
            
        }
        else{
            System.out.println("You can't move there.");
        }
        if(game.y == game.occupied[0] && game.x == game.occupied[1] && game.enemylist.size() > 0){
            game.battle = true;
        }
    }
    
    public static void moveRight(Oubliette game){
        if(game.y == 3 && game.x == 18 && game.enemylist.size() == 0){
            game.x = 0;
            game.y = 3;
            System.out.println("You go into the right door.");
            createEnemy(game);
        }
        else if(game.x<game.width-1){
            game.x += 1;
            System.out.println("You go right.");
            
        }
        else{
            System.out.println("You can't move there.");
        }
        if(game.y == game.occupied[0] && game.x == game.occupied[1] && game.enemylist.size() > 0){
            game.battle = true;
        }
    }
    
    public static void moveUp(Oubliette game){
        if(game.y == 0 && game.x == 9 && game.enemylist.size() == 0){
            game.x = 9;
            game.y = 6;
            System.out.println("You go into the upper door.");
            createEnemy(game);
        }
        else if(game.y>0){
            game.y -= 1;
            System.out.println("You go up.");
            
        }
        else{
            System.out.println("You can't move there.");
        }    
        if(game.y == game.occupied[0] && game.x == game.occupied[1] && game.enemylist.size() > 0){
            game.battle = true;
        }
    }
    
    public static void moveDown(Oubliette game){
        if(game.y == 6 && game.x == 9 && game.enemylist.size() == 0){
            game.x = 9;
            game.y = 0;
            System.out.println("You go into the lower door.");
            createEnemy(game);
        }
        else if(game.y<6){
            game.y += 1;
            System.out.println("You go down.");
        }
        else{
            System.out.println("You can't move there.");
        } 
        if(game.y == game.occupied[0] && game.x == game.occupied[1] && game.enemylist.size() > 0){
            game.battle = true;
        }
    }
    
    public static void setRoom(Oubliette game){
        for(int i = 0; i < game.height; i++){
            for(int j = 0; j < game.width; j++){
                game.grid[i][j] = ".";
            }
        }
        if(game.enemylist.size() > 0){
            game.grid[game.occupied[0]][game.occupied[1]] = game.enemylist.get(0).icon;
        }
        game.grid[game.y][game.x] = "@";
    }
    
    public static void changeRoom(Oubliette game){
        game.row1 = "";
        game.row2 = "";
        game.row3 = "";
        game.row4 = "";
        game.row5 = "";
        game.row6 = "";
        game.row7 = "";
        for(int i = 0; i < game.width; i++){
            game.row1 = game.row1 + game.grid[0][i];
        }
        for(int i = 0; i < game.width; i++){
            game.row2 = game.row2 + game.grid[1][i];
        }
        for(int i = 0; i < game.width; i++){
            game.row3 = game.row3 + game.grid[2][i];
        }
        for(int i = 0; i < game.width; i++){
            game.row4 = game.row4 + game.grid[3][i];
        }
        for(int i = 0; i < game.width; i++){
            game.row5 = game.row5 + game.grid[4][i];
        }
        for(int i = 0; i < game.width; i++){
            game.row6 = game.row6 + game.grid[5][i];
        }
        for(int i = 0; i < game.width; i++){
            game.row7 = game.row7 + game.grid[6][i];
        }
    }
    
    public static void createEnemy(Oubliette game){
        double choice = Math.random();
        if(choice < .1){
            Boss fighter = new Boss(3,9);
            game.enemylist.add(fighter);
            game.occupied[0] = 3;
            game.occupied[1] = 9;
        }
        else{
            Enemy fighter = new Enemy(3,9);
            game.enemylist.add(fighter);
            game.occupied[0] = 3;
            game.occupied[1] = 9;
        }
    }
    
    public static void die(Oubliette game){
        System.out.println("  .-\"\"\"-.");
        System.out.println(" / _   _ \\");
        System.out.println(" ](_' `_)[");
        System.out.println(" `-. ^ ,-'");
        System.out.println("   |||||");
        System.out.println("   `---'");
    }
    
    public static void hit(Oubliette game, int damage){
        if(damage<=0){
            damage = 1;
        }
        game.hp-=damage;
        System.out.println("-"+damage+"hp");
    }
    public static void entertain(Oubliette game){
        if(game.score >= game.winscore){
            endGame(game);
            System.out.println("You Win! Thanks for playing.");
        }
    }
    public static void attack(Oubliette game, int usrInt, Weapon myweapon){
        game.tp -= (5*(usrInt+1));
        int dmg = (myweapon.attack * (usrInt+1)) + (10*(usrInt+1)) + 10;
        game.enemylist.get(0).health -= dmg;
        System.out.println("You use "+ myweapon.aMoves[usrInt] +" for " +dmg+ " health.");
        System.out.println("-"+(5*(usrInt+1))+"tp");
    }
    public static void clearBonus(Oubliette game){
        game.defbonus = 0;
        game.dodbonus = 0;
        game.defmod = 1;
        game.dodmod = 1;
    }
}




